// =============================
// app.js (Desktop + clean chart version, 오류 수정)
// =============================
(() => {
  const $ = (sel) => document.querySelector(sel);
  const escapeHTML = (s) =>
    s.replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));

  let currentQuestionIndex = 0;
  let answers = [];
  let charts = {};
  let darkMode = true; // ✅ 중복 선언 제거 (아래쪽에 있던 let darkMode 지움)

  const questions = [
    "혹시 최근 주말에 가장 즐거웠던 활동은 무엇인가요?",
    "요즘 가장 눈길이 가는 뉴스 주제는 무엇인가요?",
    "만약 여유가 생긴다면 도전해보고 싶은 분야는?",
    "스트레스를 해소할 때 즐겨 하는 일은?",
    "최근 새로 배우고 있는 것이 있나요?"
  ];

  // ✅ DOMContentLoaded 내부로 모든 버튼/요소 초기화 이동
  window.addEventListener("DOMContentLoaded", () => {
    const mainScreen = $("#main-screen");
    const chatScreen = $("#chat-screen");
    const logScreen = $("#log-screen");
    const sendBtn = $("#sendBtn"); // ✅ 추가: 전송 버튼 캐싱
    const diamondBtn = $("#toggleTheme"); // ✅ 추가: 테마버튼 캐싱
    const bgBtn = $("#bgImageBtn"); // ✅ 추가: 배경버튼 캐싱
    const messages = $("#messages"); // ✅ DOM 로드 후 안전하게 가져오기

    showScreen(mainScreen);
    setDarkMode(); // ✅ 버튼들이 존재한 후 호출

    $("#btn-start")?.addEventListener("click", () => {
      showScreen(chatScreen);
      startConversation();
    });

    $("#btn-triangle")?.addEventListener("click", () => {
      showScreen(chatScreen);
      startConversation();
    });

    $("#back-from-chat")?.addEventListener("click", () => showScreen(mainScreen));
    $("#back-from-log")?.addEventListener("click", () => showScreen(mainScreen));

    sendBtn?.addEventListener("click", handleUserInput);
    $("#chatInput")?.addEventListener("keydown", (e) => e.key === "Enter" && handleUserInput());

    // ✅ 테마 전환 클릭
    diamondBtn?.addEventListener("click", () => {
      darkMode = !darkMode;
      if (darkMode) setDarkMode(); else setLightMode();
    });

    // ✅ 배경 이미지 교체
    bgBtn?.addEventListener("click", () => {
      const input = document.createElement("input");
      input.type = "file";
      input.accept = "image/*";
      input.onchange = e => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = evt => {
          document.body.style.background = `url(${evt.target.result}) no-repeat center center / cover`;
        };
        reader.readAsDataURL(file);
      };
      input.click();
    });

    // =============================
    // 내부 함수 정의 (DOMContentLoaded 안)
    // =============================

    function showScreen(target) {
      const mainScreen = document.querySelector("#main-screen");
  const chatScreen = document.querySelector("#chat-screen");
  const logScreen  = document.querySelector("#log-screen");

  [mainScreen, chatScreen, logScreen].forEach(s => s?.classList.remove("screen--active"));
  target?.classList.add("screen--active");

  const diamondBtn = document.querySelector("#toggleTheme");
  const bgBtn      = document.querySelector("#bgImageBtn");

  if (target === mainScreen) {
    // ✅ 메인화면 진입 시 항상 다크모드로 고정
    darkMode = true;                 // ✅ 수정
    setDarkMode();                   // ✅ 수정
    // 메인화면에서는 토글/배경버튼 비활성화(시각적으로 반투명)
    if (diamondBtn) { diamondBtn.style.opacity = "0.6"; diamondBtn.style.pointerEvents = "none"; }
    if (bgBtn)      { bgBtn.style.opacity = "0.6";      bgBtn.style.pointerEvents = "none"; }
  } else {
    // 채팅/로그에서는 다시 활성화
    if (diamondBtn) { diamondBtn.style.opacity = "1"; diamondBtn.style.pointerEvents = "auto"; }
    if (bgBtn)      { bgBtn.style.opacity = "1";      bgBtn.style.pointerEvents = "auto"; }
  }
    }

    function appendMessage(content, sender, isHTML = true) {
      if (!messages) return; // ✅ null 보호
      const msg = document.createElement("div");
      msg.classList.add("message", sender);
      msg.innerHTML = isHTML ? content : escapeHTML(content);
      messages.appendChild(msg);
      messages.scrollTop = messages.scrollHeight;
    }

    function startConversation() {
      currentQuestionIndex = 0;
      answers = [];
      messages.innerHTML = "";
      appendMessage("안녕하세요! 😀", "bot");
      askNextQuestion();
    }

    function askNextQuestion() {
      if (currentQuestionIndex < questions.length) {
        appendMessage(`❓ <b>질문 ${currentQuestionIndex + 1}:</b> ${questions[currentQuestionIndex]}`, "bot");
      }
    }

    async function handleUserInput() {
      const chatInput = $("#chatInput");
      const text = chatInput.value.trim();
      if (!text) return;
      appendMessage(text, "user", false);
      chatInput.value = "";

      try {
        const res = await fetch("http://192.168.100.231:5000/predict", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ sentence: text })
        });

        const data = await res.json();
        const topic = data.topic || "기타/주제";
        const scores = data.scores || {};
        const summary = data.summary || "요약 데이터를 불러올 수 없습니다.";

        answers.push(topic);
        appendMessage(`🧩 <b>예측된 주제:</b> ${topic}<br>🗒️ <b>요약:</b> ${summary}`, "bot");
        showInterimChart(scores);

        if (currentQuestionIndex < questions.length - 1) {
          currentQuestionIndex++;
          askNextQuestion();
        } else {
          appendMessage("🧠 모든 답변을 받았어요. 이제 관심사 기반 주간 계획을 생성할게요...", "bot");
          await showFinalResults();
        }
      } catch (err) {
        console.error(err);
        appendMessage("⚠️ 서버 연결 실패", "bot");
      }
    }

    // -------- 그래프 --------
    function showInterimChart(scores) {
      if (!scores || Object.keys(scores).length === 0) return;

      const chartIndex = currentQuestionIndex;
      const labels = Object.keys(scores);
      const values = Object.values(scores).map((v) => (v * 100).toFixed(1));

      const chartCard = document.createElement("div");
      chartCard.classList.add("chart-wrapper");
      chartCard.innerHTML = `
        <div style="
          background:var(--card-bg);
          border-radius:16px;
          padding:20px;
          margin:12px 0 12px 40px;
          width:400px;
          color:#2E2B3F;
          text-align:center;
          box-shadow:0 4px 12px rgba(0,0,0,0.15);
        ">
          <div id="chartLegend_${chartIndex}" style="margin-bottom:10px; font-size:14px; color:#423E57;"></div>
          <canvas id="resultChart_${chartIndex}" width="280" height="280" style="display:block; margin:0 auto;"></canvas>
          <ul style="list-style:none; padding:0; margin-top:12px; font-size:15px; line-height:1.6; text-align:left;">
            ${labels.map((l, i) => `<li>${i + 1}. ${l} — ${values[i]}%</li>`).join("")}
          </ul>
        </div>
      `;
      messages.appendChild(chartCard);
      messages.scrollTop = messages.scrollHeight;

      setTimeout(() => {
        const canvas = document.getElementById(`resultChart_${chartIndex}`);
        if (!canvas) return;
        const ctx = canvas.getContext("2d");
        if (!ctx) return;

        if (charts[chartIndex]) charts[chartIndex].destroy();

        const chart = new Chart(ctx, {
          type: "pie",
          data: {
            labels,
            datasets: [
              {
                data: values,
                backgroundColor: ["#8C6EFF", "#A88EFF", "#C2AFFF", "#DACFFF", "#E8E0FF", "#C8A2FF"],
                borderColor: "#2E2B3F",
                borderWidth: 2
              }
            ]
          },
          options: {
            responsive: false,
            maintainAspectRatio: true,
            plugins: { legend: { display: false } }
          }
        });
        charts[chartIndex] = chart;

        const legendEl = document.getElementById(`chartLegend_${chartIndex}`);
        if (legendEl) {
          const colors = chart.data.datasets[0].backgroundColor;
          legendEl.innerHTML = labels
            .map(
              (l, i) => `
              <span style="display:inline-flex;align-items:center;margin:4px 6px;">
                <span style="width:12px;height:12px;background:${colors[i]};
                  border:1px solid #2E2B3F;border-radius:2px;margin-right:6px;"></span>${l}
              </span>`
            )
            .join("");
        }
      }, 0);
    }

    // -------- GPT 결과 --------
    async function showFinalResults() {
      try {
        const gptRes = await fetch("https://api.openai.com/v1/chat/completions", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            "Authorization": "Bearer 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"
          },
          body: JSON.stringify({
            model: "gpt-3.5-turbo",
            messages: [
              { role: "system", content: "너는 사용자의 관심사에 맞춘 주간 계획을 제시하는 챗봇이야." },
              { role: "user", content: `사용자의 관심사는 ${answers.join(", ")}입니다. 각 관심사에 맞는 일주일 계획을 구체적으로 작성해줘.` }
            ]
          })
        });

        const gptData = await gptRes.json();
        const planRaw = gptData?.choices?.[0]?.message?.content || "결과를 불러올 수 없습니다.";
        const plan = planRaw.replace(/\n/g, "<br>");

        // ✅ 카드 배경 제거, 텍스트 컬러를 모드별로 자동 설정
        const textColor = darkMode ? "#FFFFFF" : "#2E2B3F";

        appendMessage(
          `
          <div style="
            background:#E8E0FF;
            border-radius:16px;
            padding:20px;
            margin:16px 0 16px 20px;
            width:400px;
            color:#2E2B3F;
            background:none; /* ✅ 배경 완전 제거 */
            text-align:left;
            
          ">
            <h3 style="margin-top:0; color:#5A4690;">✨ 최종 분석 결과입니다!</h3>
            <p>${plan}</p>
          </div>
        `,
          "bot",
          true
        );
      } catch (e) {
        console.error(e);
        appendMessage("⚠️ GPT 결과를 가져오지 못했습니다.", "bot");
      }
    }

// -------- 다크모드 --------
function setDarkMode() {
  const sendBtn    = document.querySelector("#sendBtn");
  const diamondBtn = document.querySelector("#toggleTheme");
  const bgBtn      = document.querySelector("#bgImageBtn");
  const backChat   = document.querySelector("#back-from-chat");
  const backLog    = document.querySelector("#back-from-log");

  document.documentElement.style.setProperty("--chat-bg", "#423E57");
  document.documentElement.style.setProperty("--sidebar-bg", "#7A67A1");
  document.documentElement.style.setProperty("--triangle-color", "#423E57");
  document.documentElement.style.setProperty("--input-bg", "#7A67A1");
  document.documentElement.style.setProperty("--input-inner", "#E8E0FF");
  document.documentElement.style.setProperty("--text-color", "#2E2B3F");
  document.documentElement.style.setProperty("--user-bg", "#A88EFF");
  document.documentElement.style.setProperty("--bot-bg", "#5E517A");
  document.documentElement.style.setProperty("--user-text", "#2E2B3F");
  document.documentElement.style.setProperty("--bot-text", "#FFFFFF");

  document.documentElement.style.setProperty("--card-bg", "#5E517A");
  document.documentElement.style.setProperty("--card-text", "#FFFFFF");

  sendBtn?.style && (sendBtn.style.background = "#423E57", sendBtn.style.color = "#FFFFFF");

  if (diamondBtn) {
    diamondBtn.style.background = "#5A4690";
    diamondBtn.onmouseover = () => (diamondBtn.style.background = "#A88EFF");
    diamondBtn.onmouseout = () => (diamondBtn.style.background = "#5A4690");
  }
  if (bgBtn) {
    bgBtn.style.background = "#5A4690";
    bgBtn.onmouseover = () => (bgBtn.style.background = "#A88EFF");
    bgBtn.onmouseout = () => (bgBtn.style.background = "#5A4690");
  }

  // ✅ null-safe 접근 (에러 방지)
  backChat?.style && (
    backChat.style.color = "#FFFFFF",
    backChat.style.borderColor = "#FFFFFF"
  );
  backLog?.style && (
    backLog.style.color = "#FFFFFF",
    backLog.style.borderColor = "#FFFFFF"
  );
}
// right mode
function setLightMode() {
  const sendBtn    = document.querySelector("#sendBtn");
  const diamondBtn = document.querySelector("#toggleTheme");
  const bgBtn      = document.querySelector("#bgImageBtn");
  const backChat   = document.querySelector("#back-from-chat");
  const backLog    = document.querySelector("#back-from-log");

  document.documentElement.style.setProperty("--chat-bg", "#FFFFFF");
  document.documentElement.style.setProperty("--sidebar-bg", "#DCCCFF");
  document.documentElement.style.setProperty("--triangle-color", "#FFFFFF");
  document.documentElement.style.setProperty("--input-bg", "#DCCCFF");
  document.documentElement.style.setProperty("--input-inner", "#FFFFFF");
  document.documentElement.style.setProperty("--text-color", "#2E2B3F");
  document.documentElement.style.setProperty("--user-bg", "#DCCCFF");
  document.documentElement.style.setProperty("--bot-bg", "#EDE3FF");
  document.documentElement.style.setProperty("--user-text", "#423E57");
  document.documentElement.style.setProperty("--bot-text", "#423E57");

  document.documentElement.style.setProperty("--card-bg", "#E8E0FF");
  document.documentElement.style.setProperty("--card-text", "#2E2B3F");

  sendBtn?.style && (sendBtn.style.background = "#CBB3FF", sendBtn.style.color = "#FFFFFF");

  if (diamondBtn) {
    diamondBtn.style.background = "#CBB3FF";
    diamondBtn.onmouseover = () => (diamondBtn.style.background = "#A88EFF");
    diamondBtn.onmouseout = () => (diamondBtn.style.background = "#CBB3FF");
  }
  if (bgBtn) {
    bgBtn.style.background = "#CBB3FF";
    bgBtn.onmouseover = () => (bgBtn.style.background = "#A88EFF");
    bgBtn.onmouseout = () => (bgBtn.style.background = "#CBB3FF");
  }

 backChat?.style && (
        backChat.style.color = "#2E2B3F",
        backChat.style.borderColor = "#2E2B3F"
      );
      backLog?.style && (
        backLog.style.color = "#2E2B3F",
        backLog.style.borderColor = "#2E2B3F"
      );
    }

  }); // ✅ window.addEventListener 닫힘
})();   // ✅ 즉시실행함수 닫힘